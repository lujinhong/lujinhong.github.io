---
layout: post
title:  "JavaScript 阶段总结"
date:   2015-07-09 00:06:05
categories: JavaScript
excerpt: JavaScript 知识图网 思维导图
---

做了一张思维导图。总结这几个月对 JavaScript 的学习吧，也是一个复习。

![JavaScriptNet](http://7q5cdt.com1.z0.glb.clouddn.com/blog-JavaScriptNet2.png)